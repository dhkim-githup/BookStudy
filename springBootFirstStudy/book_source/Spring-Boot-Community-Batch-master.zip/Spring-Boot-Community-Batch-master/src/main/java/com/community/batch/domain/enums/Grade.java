package com.community.batch.domain.enums;

public enum Grade {
    VIP, GOLD, FAMILY
}
