package com.community.batch.domain.enums;

/**
 * Created by KimYJ on 2018-03-14.
 */
public enum UserStatus {
    ACTIVE, INACTIVE
}
